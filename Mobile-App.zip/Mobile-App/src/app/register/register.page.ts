import { Component, OnInit ,Inject} from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';



@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {

  registerUserData :any = {}

  userdataForm : FormGroup;
  submitted = false;
  success = false;

  constructor(private _auth : AuthService, private _router: Router, public formBuilder: FormBuilder) {

    this.userdataForm = this.formBuilder.group({
      name: ['', Validators.required],
      email : ['', Validators.required],
      password : ['', Validators.required]
    })
  }
  isValid(){
    if(this.userdataForm.invalid){
      return false;
    }else {
      return true;
    }
  }
onSubmit(){
  this.submitted = true;
  if(this.userdataForm.invalid){
    return;
  }
  this.success=true;
}

  ngOnInit() {

  }


  registerUser(){

  
    this._auth.registerUser(this.registerUserData)
    .subscribe(
      res => {
        console.log(res)
        localStorage.setItem('token', res.token)
        this._router.navigate(['/login'])
      },
      err => console.log(err)
      
    )
  }

}
