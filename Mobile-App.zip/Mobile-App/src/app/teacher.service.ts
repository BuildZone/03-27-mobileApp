import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TeacherService {

  private _teachersUrl = "http://localhost:3000/api/teachers";

  constructor(private http : HttpClient) { }

  getEvents(){
    return this.http.get<any>(this._teachersUrl)
  }
}
